<p align="center">
  <img src="./docs/banner.png" alt="京东夺宝岛搜索增强" width="100%">
</p>

# 京东夺宝岛搜索增强（JD Auction Search）

<p align="center">
  <a href="./CHANGELOG.md"><img src="https://img.shields.io/badge/version-1.5.5-blue.svg" alt="version"></a>
  <a href="./LICENSE"><img src="https://img.shields.io/badge/license-MIT-green.svg" alt="license"></a>
  <img src="https://img.shields.io/badge/build-passing-brightgreen.svg" alt="build">
  <img src="https://img.shields.io/badge/manifest%20v3-FF9800.svg" alt="manifest">
  <img src="https://img.shields.io/badge/platform-Chrome%20%7C%20Edge%20%7C%20Firefox-cyan.svg" alt="platform">
</p>

<p align="center">
  京东夺宝岛（拍拍）列表页商品搜索浏览器插件 · 关键词实时过滤 · 跨页聚合 · 自动兜底
</p>

<p align="center">
  <a href="./README_EN.md">English</a> · <a href="./CHANGELOG.md">更新日志</a> · <a href="./openspec/spec.md">项目规范</a> · <a href="./openspec/tasks.md">任务</a> · <a href="./openspec/check_list.md">验收清单</a>
</p>

---

**京东夺宝岛怎么搜索商品？** 京东夺宝岛（[1paipai.jd.com](https://1paipai.jd.com)）原生列表页不支持关键词搜索，只能手动翻页找商品。本扩展为夺宝岛列表页注入一个搜索栏，输入关键词即可**跨页聚合、实时过滤**所有夺宝商品——手机、华为、数码、显卡……一搜即得，无需逐页翻找。

---

## 📑 目录

- [效果预览](#效果预览)
- [三步上手](#三步上手30-秒)
- [使用说明](#使用说明)
- [核心功能](#核心功能)
- [安装](#安装)
- [打包发布](#打包发布)
- [工作原理](#工作原理)
- [常见问题](#常见问题)
- [贡献](#贡献)
- [许可证](#许可证)

---

## 效果预览

| 搜索过滤 | 搜索历史 | 空状态 |
|----------|----------|--------|
| ![搜索](./docs/screenshots/search.png) | ![历史](./docs/screenshots/history.png) | ![空状态](./docs/screenshots/empty.png) |

<details>
<summary>📐 界面结构示意（文本版）</summary>

**搜索过滤**

```
搜索栏: [ 手机___________ ] ✕  搜索   共 128 件
网格:   [卡片][卡片][卡片][卡片][卡片]   ← 每行 5 个，红色价格 + 灰色出价 badge
        [卡片][卡片][卡片][卡片][卡片]
        加载更多（已显示 60 / 128）
```

**搜索历史**

```
搜索栏: [ __________ ] ✕  搜索
下拉:   搜索历史                  清空
        • 手机
        • 华为
        • 显卡                ×
        • 数码                ×
```

**空状态**

```
        🔍
    没有找到相关商品
  换个关键词试试，或清除当前搜索查看全部
        [ 清除搜索 ]
```

</details>

---

## 三步上手（30 秒）

1. **装**：把本项目作为「已解压扩展」加载到 Chrome / Edge / Firefox（见下方[安装](#安装)）。
2. **开**：打开任意京东夺宝岛列表页，页面顶部自动出现**搜索栏**。
3. **搜**：在搜索框输入关键词（如 `手机`、`华为`），结果**实时**刷新并覆盖展示；点 **×** 清空恢复原生列表。

就是这么简单，无需刷新页面、无需登录。

---

## 使用说明

打开京东夺宝岛列表页后，扩展会自动接管搜索体验：

| 步骤 | 操作 | 效果 |
|------|------|------|
| ① 出现搜索栏 | 进入夺宝岛列表页，等待约 2 秒 | 页面顶部自动注入搜索栏 |
| ② 输入关键词 | 在搜索框键入商品名 / ID / 分类 / 店铺 | 结果**实时**过滤，已跨页汇总全部匹配商品 |
| ③ 查看结果 | 结果面板覆盖原生列表展示 | 支持加载更多、点击卡片**新标签页**打开详情 |
| ④ 清空搜索 | 点搜索框右侧 **×** | 原生夺宝列表自动恢复，无需刷新 |
| ⑤ 无结果时 | 未匹配到商品 | 面板显示「未找到匹配商品」空状态提示 |

> 搜索时原生列表自动隐藏，清空后自动恢复；整个过程无需刷新页面。
> 搜索框聚焦且为空时会显示**历史记录下拉**（支持单条删除与一键清空），刷新后仍保留。

---

## 核心功能

- **🎯 关键词实时搜索**：按商品名称、ID、分类名、店铺名、副标题即时过滤。
- **📚 跨页聚合**：自动翻页汇总多页夺宝商品，搜索结果覆盖全部分页，告别手动翻页。
- **🛡 接口兜底**：夺宝接口不可用时自动降级为页面 DOM 数据提取，搜索不中断。
- **🕘 搜索历史**：本地持久化最近 10 条关键词，刷新不丢失。
- **🌐 多语言**：简体中文 / 英文界面。

---

## 安装

### 1. 准备图标（可选）
在 `icons/` 目录放入 3 个 PNG 图标：`icon16.png`、`icon48.png`、`icon128.png`。缺少图标也不影响加载。

### 2. 加载到浏览器
- **Chrome / Edge**：打开 `chrome://extensions/` → 开启「开发者模式」→ 点击「加载已解压的扩展程序」→ 选择本项目文件夹。
- **Firefox**：打开 `about:debugging#/runtime/this-firefox` → 点击「临时加载附加组件」→ 选择 `manifest.json`。

> 发布到应用商店时通过 `npm run build` 打包为 zip（见[打包发布](#打包发布)）。

---

## 打包发布

```bash
npm install
npm run build
```

将在 `releases/` 目录生成 `jd-auction-search-v1.5.5.zip`，可直接发布。

可选构建参数：
- `node build.js --no-preview`：跳过构建产物预览

> 注：扩展仅打包简体中文（zh_CN）+ 英文（en）单包，`--tw` / `--firefox` 多语言变体参数已移除。

---

## 工作原理

```mermaid
graph LR
  A[京东夺宝岛列表页] --> B[Content Script 注入搜索栏]
  B --> C[拦截拍拍列表接口]
  C --> D[捕获请求模板 + 分页重放]
  D --> E[跨页聚合全量商品]
  E --> F[关键词实时过滤]
  F --> G[结果面板渲染卡片]
  C -. 接口失败 .-> H[DOM 提取兜底]
  H --> F
```

- **零后端**：纯前端 MV3 扩展，无需服务器，数据全部来自当前页面。
- **接口拦截**：包裹 `fetch` / `XHR`，捕获真实列表请求作模板，逐页重放聚合多页商品。
- **优雅降级**：接口失效时自动回退到页面 DOM 提取，搜索体验不中断。
- **样式隔离**：搜索栏使用 closed Shadow DOM，结果面板用浅 DOM + 设计令牌，避免被京东页面 CSS 干扰。

---

## 常见问题

| 情况 | 处理 |
|------|------|
| 页面加载后插件无响应 | 刷新页面，或等待约 2 秒自动加载 |
| 搜索无结果 / 接口失败 | 插件会自动降级为页面数据提取模式 |
| 跨域拦截 | 已配置 `host_permissions`，通常无需处理 |

---

## 贡献

欢迎提交 Issue 与 PR。开发约定：

- 代码风格遵循 ESLint + Prettier，提交前运行 `npm run lint`。
- 测试：`npm test`（功能 + 集成）。
- 构建：`npm run build`。

---

## 许可证

[MIT License](./LICENSE)

---

### 关键词

京东夺宝岛搜索 · 拍拍搜索插件 · 夺宝岛商品筛选 · 京东拍卖关键词搜索 · 浏览器扩展 · Chrome 扩展 · Edge 插件 · Firefox 插件 · 跨页聚合搜索 · 实时过滤
